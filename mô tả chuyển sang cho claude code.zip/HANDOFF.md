# HANDOFF — HỆ THỐNG QUẢN LÝ GIẢI TRÌNH TỒN DVBH
*File này dành cho Claude Code đọc khi bắt đầu phiên làm việc mới trên dự án.*

## Bối cảnh
Hệ thống web nội bộ quản lý sự vụ DVBH: SLA, tồn đọng, vi phạm, khảo sát CSKH.
Toàn bộ thiết kế (schema, logic nghiệp vụ, UI) đã được thống nhất qua một phiên tư vấn với Claude (claude.ai). File này tổng hợp lại để Claude Code tiếp tục — không thiết kế lại từ đầu.

## Việc CẦN Claude Code làm ngay (chưa ai làm)
1. Tạo project GCP mới + bật Cloud SQL (PostgreSQL), Firebase Auth
2. Thêm Email Service Account `b2b-quanlyphidv-hn-2026@appspot.gserviceaccount.com` vào project với vai trò Viewer, báo lại ID Project cho Hoa
3. Chạy `schema.sql` (đính kèm) lên Cloud SQL để khởi tạo 7 bảng
4. Khởi tạo repo Node.js + React/Vite, đưa `import.js` và `auth-middleware.js` (đính kèm) vào làm nền
5. Tạo `secrets.md` ở gốc project, thêm vào `.gitignore` ngay, ghi đầy đủ: ID Firebase, API Keys, nội dung serviceAccount.json, Telegram Bot Token/Chat ID (chỉ dùng backup kỹ thuật), Trigger URL Cloud Functions, tài khoản admin gốc
6. Tự động backup `secrets.md` theo đường dẫn Google Drive: https://drive.google.com/drive/folders/1bsKfDYyYi68XW2HKv6rzTV0V_lQbCCLD
7. Sau khi hoàn thành + kiểm tra hoạt động tốt từng phần: `git add` → commit tiếng Việt mô tả chi tiết → push lên nhánh hiện tại của tổ chức **ETX87** trên GitHub
8. Cần thêm file TỔNG HỢP LOGIC, NHẬT KÝ LÀM VIỆC (đã có `SRS_tong_hop.md` và `nhat_ky_lam_viec.md` đính kèm — tiếp tục cập nhật các file này, không tạo trùng)

## Tech stack đã chốt
- Frontend: React + Vite
- Auth: Firebase Auth (Google Sign-In)
- Database: Cloud SQL (PostgreSQL) — nguồn dữ liệu duy nhất, KHÔNG dùng Firestore
- Backend: Node.js (Cloud Run/Cloud Functions)
- Báo cáo: SQL view/materialized view trực tiếp trên Postgres, KHÔNG dùng BigQuery giai đoạn đầu
- UI: hiện đại, tối giản, phong cách Apple, tông xanh dương/xanh nước biển tươi; **responsive nhưng ưu tiên desktop trước — phải phân biệt rõ UI/UX desktop và mobile, không dùng chung 1 bố cục co giãn đơn thuần**

## Khối lượng dữ liệu dự kiến
Data tĩnh 25.000–35.000/tháng; ghi đè+ghi mới ~1.500–2.500 ca/ngày; log ~200–300 ca/ngày; khảo sát ~400–1.000 ca/ngày. → 1 Cloud SQL instance nhỏ (2 vCPU/4-8GB) là đủ, không cần BigQuery/read replica ở giai đoạn này.

## Vai trò & phân quyền
Admin (full), Viewer (full view), QC (như Viewer + chốt/bỏ vi phạm cấp 2), Giám sát (view + giải trình theo khu vực phụ trách), TBP DVBH (quản lý nhiều Giám sát), CSKH (khảo sát + chốt vi phạm cấp 1), TN CSKH (như CSKH + phân công khảo sát + sửa data khảo sát nhầm), TBP CSKH (như TN CSKH + full view). KTV không có tài khoản, chỉ là field dữ liệu. Đăng nhập Google → chờ Admin duyệt + gán vai trò/khu vực mới truy cập được.

## Logic nghiệp vụ cốt lõi
1. **Import hàng ngày**: so khớp theo ID. CRM nguồn tự trả sẵn 4 cột true/false (Lỗi 120', Quá hẹn 24h, Lỡ kế hoạch, KH hẹn lại) — KHÔNG tự tính công thức từ timestamp. NaN/rỗng = false.
2. **Ratchet 1 chiều**: DB đang true → giữ true (bỏ qua import); DB đang false, import true → cập nhật true. Logic đầy đủ đã code trong `import.js`.
3. **4 nhánh xử lý mỗi dòng import**: GHI_MOI (ID mới) / BO_QUA (case đã hoàn thành + không đổi) / CAP_NHAT_MOC_THOI_GIAN (ca tồn + không đổi, chỉ update ngay_cap_nhat_gan_nhat + ratchet) / GHI_DE (có thay đổi).
4. **Khảo sát & chốt vi phạm 2 cấp**: CSKH/TN CSKH/TBP CSKH gọi khảo sát → chốt cấp 1 (`ket_qua_cap_1`) → QC xét → chốt/bỏ cấp 2 (`chot_bo_cap_2`, final). Không được nhảy cấp. 1 cuộc gọi có thể khảo sát nhiều loại lỗi cùng lúc.
5. **Tỷ lệ vi phạm dùng cho báo cáo** = `COALESCE(chot_bo_cap_2, ket_qua_cap_1 khác "Không lỗi")` — ưu tiên cấp 2, fallback cấp 1 nếu chưa có cấp 2.
6. **Ca tồn** = case chưa có `thoi_gian_hoan_thanh`. Giám sát giải trình định kỳ 3 ngày/lần, mỗi giải trình 1 dòng log, không ghi đè, lưu vĩnh viễn.
7. **Chính sách lưu trữ**: case đã hoàn thành giữ 3 tháng rồi archive; case tồn giữ vĩnh viễn; log luôn lưu vĩnh viễn bất kể trạng thái case.
8. **Danh mục linh kiện** (`linh_kien`): Admin CRUD + tắt/bật hiển thị khi chọn trong giải trình; linh kiện bị tắt vẫn giữ nguyên trong giải trình cũ.

## Dashboard Tổng quát (đã duyệt UI, cần code lại thật)
4 nhóm: SLA (hiệu suất xử lý), Vi phạm, Ca tồn & giải trình, Khảo sát. Doanh thu và Khối lượng công việc tách riêng module khác. Có báo cáo dạng bảng pivot đổi chiều nhóm (khu vực/đối tác/hãng/tỉnh/KTV), cột tỷ lệ đứng trước số liệu tuyệt đối.

## File đính kèm trong bộ bàn giao này
- `schema.sql` — DDL đầy đủ 7 bảng (users, settings_ly_do, linh_kien, case_dvbh, giai_trinh, ket_qua_goi, vi_pham)
- `import.js` — logic import Node.js hoàn chỉnh (ratchet, 4 nhánh xử lý, transaction tuần tự)
- `auth-middleware.js` — middleware xác thực Firebase + phân quyền vai trò/khu vực
- `SRS_tong_hop.md` — tổng hợp toàn bộ quyết định thiết kế
- `nhat_ky_lam_viec.md` — nhật ký các buổi làm việc trước

## Việc còn mở / cần xác nhận thêm với user
- Vai trò quản lý bảng `linh_kien`: tạm mặc định Admin only
- Chưa code thật: API endpoint đầy đủ, UI React (mới có wireframe/mockup tĩnh cho Dashboard Tổng quát), job archive dữ liệu >3 tháng
- Chưa có Firebase project, chưa có GitHub repo thật, chưa có secrets.md — Claude Code cần tạo mới hoàn toàn
