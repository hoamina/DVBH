# NHẬT KÝ LÀM VIỆC — HỆ THỐNG QUẢN LÝ GIẢI TRÌNH TỒN DVBH

## 2026-07-15

- Đọc bản yêu cầu hệ thống v2, xác nhận nắm logic nghiệp vụ (4 điều kiện nghi ngờ vi phạm, quy trình chốt 2 cấp, logic ca tồn, chính sách lưu trữ)
- Tư vấn nền tảng: đề xuất chuyển từ Firestore + BigQuery sang PostgreSQL (Cloud SQL) + Firebase Auth, do khối lượng dữ liệu vừa phải (~25-35k case/tháng) và logic nghiệp vụ nặng về quan hệ/báo cáo đa chiều — PostgreSQL xử lý tốt hơn mà không cần đồng bộ 2 hệ. User đồng ý.
- User cung cấp file Data_import mẫu (5 sheet: DATA, GIAI TRINH, KET QUA GOI, LOI GHI NHAN, SETTINGS) — dùng làm cơ sở thiết kế schema chi tiết
- Điều chỉnh logic: CRM nguồn tự tính sẵn 4 cột true/false nghi ngờ vi phạm, app chỉ áp quy tắc ratchet 1 chiều (false→true, không revert) khi ghi đè
- Xác nhận: NaN = false; 3 sheet GIAI TRINH/KET QUA GOI/LOI GHI NHAN chỉ là ví dụ cấu trúc không cần migrate; cột ĐÚNG HẠN/XỬ LÝ 24h chỉ phục vụ báo cáo SLA; cột "TBP" trong file nguồn thực chất là Khu vực
- Thiết kế và duyệt cấu trúc ERD 6 bảng (bằng mô tả chữ do lỗi render sơ đồ), sau đó bổ sung bảng thứ 7 `linh_kien` (danh mục linh kiện dùng khi giải trình, có Admin CRUD + tắt/bật hiển thị)
- Hoàn thành `schema.sql` đầy đủ 7 bảng (users, settings_ly_do, linh_kien, case_dvbh, giai_trinh, ket_qua_goi, vi_pham) với index, FK, CHECK constraint
- Khởi tạo `SRS_tong_hop.md` tổng hợp toàn bộ quyết định thiết kế

### Việc tiếp theo
- Xác nhận vai trò quản lý bảng linh_kien
- Thiết kế API backend (Node.js) cho luồng import
- Thiết kế UI/UX từng module
